# Arduino-STK500

This is libs of STK500 Communication protocol for node.js.

# Run

```
node unoSample.js
```

# Reference.
[AVR061: STK500 Communication Protocol](http://www.atmel.com/images/doc2525.pdf)